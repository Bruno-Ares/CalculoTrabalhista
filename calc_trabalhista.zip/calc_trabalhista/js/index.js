const inputValorHora = document.querySelector("#inputValorHora")
const inputHora= document.querySelector("#inputHora")
const inputVale = document.querySelector("#inputVale")
const inputDeducoes = document.querySelector("#inputDeducoes")

const btnConfirmar = document.querySelector("#btnConfirmar")
const btnLimpar = document.querySelector("#btnLimpar")

function Inss(num) //Funcao para calculo do INSS
{
    let valorFinal

    if (num <= 1412.00)
    {
        valorFinal = num * 0.075

    } else if (num <= 2666.68)
    {
        valorFinal = 105.9 + (num - 1412.00) * 0.09 
        // 1412.00 * 0.075 + [valorRestante] * 9.0
    } else if (num <= 4000.03)
    {
        valorFinal = 218.82 + (num - 2666.68) * 0.12
        // 1412.00 * 0.075 +  (2666.68 - 1412.0) * 0.09 + [valorRestante] * 0.12
    } else if (num <= 7786.02) 
    {
        valorFinal = 378.82 + (num - 4000.03) * 0.14 
        //1412.00 * 0.075 +  (2666.68 - 1412.0) * 0.09 + (4000.03 - 2666.68) * 0.12 + [valorRestante] * 0.12
    } else
    {
        valorFinal = 908.82
        //1412.00 * 0.075 +  (2666.68 - 1412.0) * 0.09 + (4000.03 - 2666.68) * 0.12 + (7786.02 - 4000.03) * 0.14
    }

    return valorFinal
} 

function Irpf(num) //Funcao para calculo do IPRF
{
    let valorFinal

    if (num <= 2112.0)
    {
        valorFinal = 0

    } else if (num <= 2826.65)
    {
        valorFinal = num*0.075 - 169.44 

    } else if (num <= 3751.05)
    {
        valorFinal = num*0.15 - 381.44

    } else if (num <= 4664.68) 
    {
        valorFinal = num*0.225 -  662.77

    } else
    {
        valorFinal = num * 0.275 - 896.00
    }

    return valorFinal
} 


btnConfirmar.addEventListener("click", () =>{
    let valorHora = parseFloat(inputValorHora.value)
    let hora = parseInt(inputHora.value)
    let valorVale = 0

    let salTotal = valorHora * hora
    let descontos = parseFloat(inputDeducoes.value)

    if (inputVale.checked) {valorVale = salTotal * 0.06} 
    
    let valorINSS = Inss(salTotal)
    let valorIRPF = Irpf(salTotal)

    let salLiquido = salTotal - valorVale - valorINSS - valorIRPF - descontos


    document.getElementById("divSalBruto").innerHTML = "R$ " + salTotal.toFixed(2).toString().replace(".", ",")
    document.getElementById("divINSS").innerHTML = "R$ " + valorINSS.toFixed(2).toString().replace(".", ",")
    document.getElementById("divIRPF").innerHTML = "R$ " + valorIRPF.toFixed(2).toString().replace(".", ",")
    document.getElementById("divValTrans").innerHTML = "R$ " + valorVale.toFixed(2).toString().replace(".", ",")
    document.getElementById("divOutros").innerHTML = "R$ " + descontos.toFixed(2).toString().replace(".", ",")
    document.getElementById("divSalLiq").innerHTML = "R$ " + salLiquido.toFixed(2).toString().replace(".", ",")




})
